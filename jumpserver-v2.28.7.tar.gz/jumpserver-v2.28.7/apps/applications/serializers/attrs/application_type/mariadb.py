from .mysql import MySQLSerializer

__all__ = ['MariaDBSerializer']


class MariaDBSerializer(MySQLSerializer):
    pass
