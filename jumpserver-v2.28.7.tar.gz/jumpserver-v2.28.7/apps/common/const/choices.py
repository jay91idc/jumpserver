
ADMIN = 'Admin'
USER = 'User'
AUDITOR = 'Auditor'
